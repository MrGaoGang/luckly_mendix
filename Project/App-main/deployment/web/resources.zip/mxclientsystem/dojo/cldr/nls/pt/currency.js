/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/pt/currency",{HKD_displayName:"D\u00f3lar de Hong Kong",CHF_displayName:"Franco su\u00ed\u00e7o",JPY_symbol:"JP\u00a5",CAD_displayName:"D\u00f3lar canadense",HKD_symbol:"HK$",CNY_displayName:"Yuan chin\u00eas",USD_symbol:"US$",AUD_displayName:"D\u00f3lar australiano",JPY_displayName:"Iene japon\u00eas",CAD_symbol:"CA$",USD_displayName:"D\u00f3lar norte-americano",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"Libra esterlina brit\u00e2nica",GBP_symbol:"\u00a3",AUD_symbol:"AU$",
EUR_displayName:"Euro"});
