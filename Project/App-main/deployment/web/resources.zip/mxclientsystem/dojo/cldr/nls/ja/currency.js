/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ja/currency",{HKD_displayName:"\u9999\u6e2f\u30c9\u30eb",CHF_displayName:"\u30b9\u30a4\u30b9 \u30d5\u30e9\u30f3",JPY_symbol:"\uffe5",CAD_displayName:"\u30ab\u30ca\u30c0 \u30c9\u30eb",HKD_symbol:"HK$",CNY_displayName:"\u4e2d\u56fd\u4eba\u6c11\u5143",USD_symbol:"$",AUD_displayName:"\u30aa\u30fc\u30b9\u30c8\u30e9\u30ea\u30a2 \u30c9\u30eb",JPY_displayName:"\u65e5\u672c\u5186",CAD_symbol:"CA$",USD_displayName:"\u7c73\u30c9\u30eb",EUR_symbol:"\u20ac",CNY_symbol:"\u5143",GBP_displayName:"\u82f1\u56fd\u30dd\u30f3\u30c9",
GBP_symbol:"\u00a3",AUD_symbol:"AU$",EUR_displayName:"\u30e6\u30fc\u30ed"});
