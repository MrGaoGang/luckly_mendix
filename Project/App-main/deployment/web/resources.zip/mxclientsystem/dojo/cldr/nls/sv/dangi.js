/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sv/dangi",{"field-sat-relative+0":"l\u00f6rdag denna vecka","field-sat-relative+1":"l\u00f6rdag n\u00e4sta vecka","field-dayperiod":"fm/em","field-sun-relative+-1":"s\u00f6ndag f\u00f6rra veckan","field-mon-relative+-1":"m\u00e5ndag f\u00f6rra veckan","field-minute":"Minut","field-day-relative+-1":"i g\u00e5r","field-weekday":"Veckodag","field-day-relative+-2":"i f\u00f6rrg\u00e5r","field-era":"Era","field-hour":"timme","field-sun-relative+0":"s\u00f6ndag denna vecka","field-sun-relative+1":"s\u00f6ndag n\u00e4sta vecka",
"field-wed-relative+-1":"onsdag f\u00f6rra veckan","field-day-relative+0":"i dag","field-day-relative+1":"i morgon","field-day-relative+2":"i \u00f6vermorgon","field-tue-relative+0":"tisdag denna vecka","field-zone":"Tidszon","field-tue-relative+1":"tisdag n\u00e4sta vecka","field-week-relative+-1":"f\u00f6rra veckan","field-year-relative+0":"i \u00e5r","field-year-relative+1":"n\u00e4sta \u00e5r","field-sat-relative+-1":"l\u00f6rdag f\u00f6rra veckan","field-year-relative+-1":"i fjol","field-year":"\u00c5r",
"field-fri-relative+0":"fredag denna vecka","field-fri-relative+1":"fredag n\u00e4sta vecka","field-week":"Vecka","field-week-relative+0":"denna vecka","field-week-relative+1":"n\u00e4sta vecka","field-month-relative+0":"denna m\u00e5nad","field-month":"M\u00e5nad","field-month-relative+1":"n\u00e4sta m\u00e5nad","field-fri-relative+-1":"fredag f\u00f6rra veckan","field-second":"Sekund","field-tue-relative+-1":"tisdag f\u00f6rra veckan","field-day":"Dag","field-mon-relative+0":"m\u00e5ndag denna vecka",
"field-mon-relative+1":"m\u00e5ndag n\u00e4sta vecka","field-thu-relative+0":"torsdag denna vecka","field-second-relative+0":"nu","field-thu-relative+1":"torsdag n\u00e4sta vecka","field-wed-relative+0":"onsdag denna vecka","field-wed-relative+1":"onsdag n\u00e4sta vecka","field-month-relative+-1":"f\u00f6rra m\u00e5naden","field-thu-relative+-1":"torsdag f\u00f6rra veckan"});
