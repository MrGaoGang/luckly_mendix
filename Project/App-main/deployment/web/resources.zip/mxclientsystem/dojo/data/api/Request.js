/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/data/api/Request",["../../_base/declare"],function(a){return a("dojo.data.api.Request",null,{abort:function(){throw Error("Unimplemented API: dojo.data.api.Request.abort");}})});
