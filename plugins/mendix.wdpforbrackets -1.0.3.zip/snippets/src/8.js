// Loading jQuery
            _loadJQuery : function(){
                var jQuery = _jQuery();

                // Get the jQuery and jQuery UI library
                this.$ = jQuery.jQuery();

            },
