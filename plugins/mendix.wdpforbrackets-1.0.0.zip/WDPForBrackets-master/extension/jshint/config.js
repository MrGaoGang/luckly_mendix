/*
 * Copyright (c) 2012 Raymond Camden
 * 
 * See the file LICENSE for copying permission.
 */

{
	"options": {"undef":true},
	"globals": {}
}
