// Resume
            resume : function(){
                // TODO What to do on resume?
            },

            // Suspend
            suspend : function(){
                // TODO What to do on suspend?
            },
