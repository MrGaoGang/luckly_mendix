//>>built
define("dijit/tree/model",["dojo/_base/declare"],function(b){return b("dijit.tree.model",null,{destroy:function(){},getRoot:function(a){},mayHaveChildren:function(a){},getChildren:function(a,c){},isItem:function(a){},getIdentity:function(a){},getLabel:function(a){},newItem:function(a,c,b,d){},pasteItem:function(a,c,b,d,e,f){},onChange:function(a){},onChildrenChange:function(a,b){}})});
