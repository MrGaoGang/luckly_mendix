//>>built
define("dijit/form/nls/ro/validate",{invalidMessage:"Valoarea introdus\u0103 nu este valid\u0103.",missingMessage:"Aceast\u0103 valoare este necesar\u0103.",rangeMessage:"Aceast\u0103 valoare este \u00een afara intervalului. "});
