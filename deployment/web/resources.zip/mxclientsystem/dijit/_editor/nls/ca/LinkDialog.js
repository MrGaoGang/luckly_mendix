//>>built
define("dijit/_editor/nls/ca/LinkDialog",{createLinkTitle:"Propietats de l'enlla\u00e7",insertImageTitle:"Propietats de la imatge",url:"URL:",text:"Descripci\u00f3:",target:"Destinaci\u00f3:",set:"Defineix",currentWindow:"Finestra actual",parentWindow:"Finestra pare",topWindow:"Finestra superior",newWindow:"Finestra nova"});
