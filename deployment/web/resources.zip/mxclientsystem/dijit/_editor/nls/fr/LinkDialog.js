//>>built
define("dijit/_editor/nls/fr/LinkDialog",{createLinkTitle:"Propri\u00e9t\u00e9s du lien",insertImageTitle:"Propri\u00e9t\u00e9s de l'image",url:"URL :",text:"Description :",target:"Cible :",set:"D\u00e9finir",currentWindow:"Fen\u00eatre actuelle",parentWindow:"Fen\u00eatre parent",topWindow:"Fen\u00eatre sup\u00e9rieure",newWindow:"Nouvelle fen\u00eatre"});
