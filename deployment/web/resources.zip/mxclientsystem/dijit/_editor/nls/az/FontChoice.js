//>>built
define("dijit/_editor/nls/az/FontChoice",{1:"xx-ki\u00e7ik",2:"x-ki\u00e7ik",formatBlock:"Format",3:"ki\u00e7ik",4:"orta",5:"b\u00f6y\u00fck",6:"\u00e7ox-b\u00f6y\u00fck",7:"\u0259n b\u00f6y\u00fck",fantasy:"fantaziya",serif:"serif",p:"Abzas",pre:"\u018fvv\u0259ld\u0259n d\u00fcz\u0259ldilmi\u015f","sans-serif":"sans-serif",fontName:"\u015erift",h1:"Ba\u015fl\u0131q",h2:"Alt Ba\u015fl\u0131q",h3:"Alt Alt Ba\u015fl\u0131q",monospace:"T\u0259k aral\u0131ql\u0131",fontSize:"\u00d6l\u00e7\u00fc",cursive:"\u018fl yaz\u0131s\u0131",
noFormat:"He\u00e7 biri"});
