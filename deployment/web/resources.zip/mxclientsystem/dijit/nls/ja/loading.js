//>>built
define("dijit/nls/ja/loading",{loadingState:"\u30ed\u30fc\u30c9\u4e2d...",errorState:"\u30a8\u30e9\u30fc\u304c\u767a\u751f\u3057\u307e\u3057\u305f\u3002"});
