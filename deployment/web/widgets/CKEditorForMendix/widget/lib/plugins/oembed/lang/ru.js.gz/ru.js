CKEDITOR.plugins.setLang('oembed', 'ru', {
    title : "Внедрить медиа-контент (Фото, Видео и т.д.)",
    button : "Внедрить медиа-контент с различных сайтов",
    pasteUrl : "Вставьте ссылку на страницы с медиа-контентом  (e.g. YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.)",
    width : "Макс. ширина:",
    height : "Макс. высота:",
    invalidUrl : "Вы ввели некорректный URL",
    noEmbedCode : "Не обнаружен код для вставки. Возможно, вы ввели ссылку с неподдерживаемого сайта.",
	url : "URL:",
	widthTitle : "Maximum Width for the embeded Content",
	heightTitle : "Maximum Height for the embeded Content"
});
