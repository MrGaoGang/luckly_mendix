define([
    "dojo/_base/declare",
    "DataGridExtension/widget/DataGridExtension" ],
    function(declare, DataGridExtension) {
        "use strict";

        return declare("DataGridExtension.widget.DataGridExtensionNoContext", DataGridExtension, {
            /* */
        });
    }
);
