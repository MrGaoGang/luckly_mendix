define('widgets/nls/widgets_sl',{
'dijit/nls/loading':{"loadingState":"Nalaganje ...","errorState":"Oprostite, prišlo je do napake.","_localized":{}}
});