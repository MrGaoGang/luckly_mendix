define('widgets/nls/widgets_zh-tw',{
'dijit/nls/loading':{"loadingState":"載入中...","errorState":"抱歉，發生錯誤","_localized":{}}
});