define('widgets/nls/widgets_pt-pt',{
'dijit/nls/loading':{"loadingState":"A carregar...","errorState":"Lamentamos, mas ocorreu um erro","_localized":{}}
});