define('widgets/nls/widgets_fr-fr',{
'dijit/nls/loading':{"loadingState":"Chargement...","errorState":"Une erreur est survenue","_localized":{}}
});