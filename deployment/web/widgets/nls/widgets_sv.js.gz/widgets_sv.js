define('widgets/nls/widgets_sv',{
'dijit/nls/loading':{"loadingState":"Läser in...","errorState":"Det har inträffat ett fel.","_localized":{}}
});