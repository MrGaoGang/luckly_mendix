define('widgets/nls/widgets_he-il',{
'dijit/nls/loading':{"loadingState":"טעינה...‏","errorState":"אירעה שגיאה","_localized":{}}
});