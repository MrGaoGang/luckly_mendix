define('widgets/nls/widgets_es-es',{
'dijit/nls/loading':{"loadingState":"Cargando...","errorState":"Lo siento, se ha producido un error","_localized":{}}
});