define('widgets/nls/widgets_de',{
'dijit/nls/loading':{"loadingState":"Wird geladen...","errorState":"Es ist ein Fehler aufgetreten.","_localized":{}}
});