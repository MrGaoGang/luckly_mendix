define('widgets/nls/widgets_el',{
'dijit/nls/loading':{"loadingState":"Φόρτωση...","errorState":"Σας ζητούμε συγνώμη, παρουσιάστηκε σφάλμα","_localized":{}}
});