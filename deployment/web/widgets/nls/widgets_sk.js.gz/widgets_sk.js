define('widgets/nls/widgets_sk',{
'dijit/nls/loading':{"loadingState":"Zavádza sa...","errorState":"Ľutujeme, ale vyskytla sa chyba","_localized":{}}
});