define('widgets/nls/widgets_fi-fi',{
'dijit/nls/loading':{"loadingState":"Lataus on meneillään...","errorState":"On ilmennyt virhe.","_localized":{}}
});