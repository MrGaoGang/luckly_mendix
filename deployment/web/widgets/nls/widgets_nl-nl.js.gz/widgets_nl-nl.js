define('widgets/nls/widgets_nl-nl',{
'dijit/nls/loading':{"loadingState":"Bezig met laden...","errorState":"Er is een fout opgetreden","_localized":{}}
});