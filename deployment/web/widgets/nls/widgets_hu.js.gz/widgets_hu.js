define('widgets/nls/widgets_hu',{
'dijit/nls/loading':{"loadingState":"Betöltés...","errorState":"Sajnálom, hiba történt","_localized":{}}
});