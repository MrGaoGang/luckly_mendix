define('widgets/nls/widgets_ar',{
'dijit/nls/loading':{"loadingState":"جاري التحميل...","errorState":"عفوا، حدث خطأ","_localized":{}}
});