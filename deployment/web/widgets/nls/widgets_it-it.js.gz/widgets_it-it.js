define('widgets/nls/widgets_it-it',{
'dijit/nls/loading':{"loadingState":"Caricamento in corso...","errorState":"Si è verificato un errore","_localized":{}}
});