define('widgets/nls/widgets_en-gb',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred","_localized":{}}
});