define('widgets/nls/widgets_pl',{
'dijit/nls/loading':{"loadingState":"Ładowanie...","errorState":"Niestety, wystąpił błąd","_localized":{}}
});