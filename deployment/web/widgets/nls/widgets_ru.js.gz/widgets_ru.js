define('widgets/nls/widgets_ru',{
'dijit/nls/loading':{"loadingState":"Загрузка...","errorState":"Извините, возникла ошибка","_localized":{}}
});