define('widgets/nls/widgets_ja-jp',{
'dijit/nls/loading':{"loadingState":"ロード中...","errorState":"エラーが発生しました。","_localized":{}}
});