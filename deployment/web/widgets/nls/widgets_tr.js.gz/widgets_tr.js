define('widgets/nls/widgets_tr',{
'dijit/nls/loading':{"loadingState":"Yükleniyor...","errorState":"Üzgünüz, bir hata oluştu","_localized":{}}
});