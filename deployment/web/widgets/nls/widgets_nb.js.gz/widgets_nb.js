define('widgets/nls/widgets_nb',{
'dijit/nls/loading':{"loadingState":"Laster inn...","errorState":"Det oppsto en feil","_localized":{}}
});