define('widgets/nls/widgets_cs',{
'dijit/nls/loading':{"loadingState":"Probíhá načítání...","errorState":"Omlouváme se, došlo k chybě","_localized":{}}
});