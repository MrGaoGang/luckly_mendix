define('widgets/nls/widgets_pt-br',{
'dijit/nls/loading':{"loadingState":"Carregando...","errorState":"Desculpe, ocorreu um erro","_localized":{}}
});