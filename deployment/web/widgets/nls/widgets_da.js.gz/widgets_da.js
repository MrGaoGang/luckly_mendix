define('widgets/nls/widgets_da',{
'dijit/nls/loading':{"loadingState":"Indlæser...","errorState":"Der er opstået en fejl","_localized":{}}
});