define('widgets/nls/widgets_en-us',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred","_localized":{}}
});