define('widgets/nls/widgets_th',{
'dijit/nls/loading':{"loadingState":"กำลังโหลด...","errorState":"ขออภัย เกิดข้อผิดพลาด","_localized":{}}
});